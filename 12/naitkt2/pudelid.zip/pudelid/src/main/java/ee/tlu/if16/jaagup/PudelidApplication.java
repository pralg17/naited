package ee.tlu.if16.jaagup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PudelidApplication {

	public static void main(String[] args) {
		SpringApplication.run(PudelidApplication.class, args);
	}
}
